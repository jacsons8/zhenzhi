# -*- coding:utf-8 -*-
from distutils.core import setup
from setuptools import find_packages
import setuptools
with open("README.rst", "r",encoding="utf8") as f:
  long_description = f.read()

setup(name='paramTransfer',  # 包名
      version='1.0.0',  # 版本号
      description='pjt param transfer',
      long_description=long_description,
      author='hsy',
      author_email='532848352@qq.com',
      url='https://mp.weixin.qq.com/s/9FQ-Tun5FbpBepBAsdY62w',
      license='BSD License',
      platforms=["all"],
      classifiers=[
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Natural Language :: Chinese (Simplified)',
          'Programming Language :: Python :: 3.7',
          'Programming Language :: Python :: 3.8',
          'Topic :: Software Development :: Libraries'
      ],packages=setuptools.find_namespace_packages(
                     include=["data","data.*"], ),
                 install_requires=["pickle","traceback","json"]
      ,include_package_data=True

      )
